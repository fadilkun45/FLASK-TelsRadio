
/* - Js Custom Function
===============================================================*/

  "use strict";

/* Main Functions */

var allMaster = {
    init: function() {
      this.Basic.init();
    },
    Basic: {
        init: function() {
            this.onePageNavigation();
            this.windowHeight();
            this.allmasterMenu();
            this.goToNextSection();
            this.photoLightBox();
            this.testimonialSlider();
            this.allmasterBoxer();
            this.allmasterCounter();
            this.mailChimpAjax();
            this.allmasterMapToggle();
            this.contactForm();
            this.allmasterWow();
            this.scrollUp();
        },
        onePageNavigation: function() {
            $('#main-nav').onePageNav({
                currentClass: 'active',
                changeHash: !1,
                scrollSpeed: 1200,
                scrollOffset: 70,
                filter: ':not(.sub-menu a, .not-home)'
            })
        },
        windowHeight: function() {
          /*  - Cslider Windows Bg
          ------------------------------------------------*/
          jQuery(function($) {
            "use strict";

            sliderAddHeight(); 

            $(window).on("load resize scroll",function(e){ 
                sliderAddHeight();
            });

            function sliderAddHeight(){
              var wh =  $(window).height(); 
              var ww =  $(window).width();

              var $s1 = $('#slider .slider-container'); 
                $s1.css({'height': wh });
                // if (ww>1300){ $s1.css({'height': wh });}
            }
          });
        },
        allmasterMenu: function() {
            $(window).on("scroll", function() {
                if ($(this).scrollTop() > 1){  
                    $('.main-menu').addClass("menu-bg-overlay");
                  }
                  else{
                    $('.main-menu').removeClass("menu-bg-overlay");
                  }
            });
        },
        goToNextSection: function() {
          /*----------- Scroll to Feature Section ----------*/ 
          $('#go-to-next').on("click", function() {
            $('html,body').animate({scrollTop:$('#about').offset().top - 80}, 1000);
          });
        },
         photoLightBox: function() {
        /*-------------- lsb lightbox ------------------*/  
            $.fn.lightspeedBox({
                slideShowTiming: 5000,
            });
        },
        testimonialSlider: function() {
            $('.testimonial-slider').owlCarousel({
                items: 1,
                loop: true,
                autoplay: true,
                autoplayTimeout:5000,
                autoplaySpeed:5000,
                smartSpeed:450,
                animateIn: 'slideInDown',
                animateOut: 'slideOutDown',
            });
        },
        allmasterBoxer: function() {
            /*  - Boxer 
            ---------------------------------------------------*/
              jQuery(".boxer").boxer({ 
                  margin:100
              }); 
            /*   - Boxer end 
            ---------------------------------------------------*/
        },
        allmasterCounter: function() {
            /*   - CounterUp
            ---------------------------------------------------*/
              $('.counter').counterUp({
                  delay: 10,
                  time: 1000
              });
            /*   - CounterUp end 
            ---------------------------------------------------*/
        },
        mailChimpAjax: function() {
          $('#mc-form').ajaxChimp({});
        },
        allmasterMapToggle: function() {
          /*  - Google Map toggle 
          ---------------------------------------------------*/
              $( ".toggle-pade" ).on("click", function() {
                $( "#google-map" ).slideToggle( "slow" );
              });
          /*   - Google Map toggle end 
          ---------------------------------------------------*/
          /*   - Google Map - with support of gmaps.js 
          --------------------------------------------------------------------*/ 
     
          $(window).on("load",function(e){
            jQuery("#google-map").css({'display':'none'});
          });

            function isMobile() { 
              return ('ontouchstart' in document.documentElement);
            }

            function init_gmap() {
              if ( typeof google == 'undefined' ) return;
              var options = {
                center: [23.739339, 90.389191],
                zoom: 15,
                mapTypeControl: true,
                mapTypeControlOptions: {
                  style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
                },
                navigationControl: true,
                scrollwheel: false,
                streetViewControl: true
              }

              if (isMobile()) {
                options.draggable = false;
              }

              $('#googleMaps').gmap3({
                map: {
                  options: options
                },
                marker: {
                  latLng: [23.739339, 90.389191],
                  options: { icon: 'assets/images/map-icon.png' }
                }
              });
            }
            init_gmap();
          /*   - Google Map - with support of gmaps.js End 
          --------------------------------------------------------------------*/
        },
        contactForm: function() {
          $('form#contact-form').submit(function() {
            $('form#contact-form .error').remove();
            var hasError = false;
          
            if(!hasError) {
            $("#loader").show();
            $.ajax({
              url: "contact.php",
              type: "POST",
              data:  new FormData(this),
              contentType: false,
              cache: false,
              processData:false,
              success: function(data){
                $('form#contact-form').slideUp("fast", function() {
                $(this).before('<div class="success">Thank you. Your email was sent successfully.</div>');
                $("#loader").hide();
                })
              }
            });    
              return false;
            }
         
          });
        },
        allmasterWow: function(){
            /*  - wow animation wow.js 
            ---------------------------------------------------*/
              var wow = new WOW(
                {
                  boxClass:     'wow',      // animated element css class (default is wow)
                  animateClass: 'animated', // animation css class (default is animated)
                  offset:       0,          // distance to the element when triggering the animation (default is 0)
                  mobile:       false       // trigger animations on mobile devices (true is default)
                }
              );
              wow.init();
            /*  - wow animation wow.js End 
            ---------------------------------------------------*/
        },
        scrollUp: function() {
            jQuery('.scrollup').on('click', function() {
                jQuery("html, body").animate({
                    scrollTop: 0
                }, 2000);
                return !1
            })
        },

    },//Basic
   
}; //allMaster

$(document).ready(function (){
    allMaster.init();

    jQuery(window).on("load resize", function(e) {
        jQuery('#preloader').fadeOut('slow', function() {
            jQuery(this).remove()
        })
    });
});