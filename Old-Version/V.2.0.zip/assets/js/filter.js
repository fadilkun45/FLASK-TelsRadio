
$(document).ready(function (){
	/*  - Filter
  	-------------------------------------------------*/
  	var containerEl = document.querySelector('.grid-filter');
  	var mixer = mixitup(containerEl);
});